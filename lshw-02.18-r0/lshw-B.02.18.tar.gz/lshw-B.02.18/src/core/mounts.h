#ifndef _MOUNTS_H_
#define _MOUNTS_H_

#include "hw.h"

bool scan_mounts(hwNode & n);
#endif
