#ifndef _DASD_H_
#define _DASD_H_

#include "hw.h"

bool scan_dasd(hwNode & n);
#endif
