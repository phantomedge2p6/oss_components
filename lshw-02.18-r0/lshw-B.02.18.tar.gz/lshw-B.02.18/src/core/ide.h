#ifndef _IDE_H_
#define _IDE_H_

#include "hw.h"

bool scan_ide(hwNode & n);
#endif
