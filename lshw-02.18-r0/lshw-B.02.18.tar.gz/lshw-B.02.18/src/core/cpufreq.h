#ifndef _CPUFREQ_H_
#define _CPUFREQ_H_

#include "hw.h"

bool scan_cpufreq(hwNode & n);
#endif
