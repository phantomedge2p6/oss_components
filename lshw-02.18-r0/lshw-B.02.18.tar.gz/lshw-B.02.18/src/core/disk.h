#ifndef _DISK_H_
#define _DISK_H_

#include "hw.h"

bool scan_disk(hwNode & n);
#endif
