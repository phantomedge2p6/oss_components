#ifndef _NETWORK_H_
#define _NETWORK_H_

#include "hw.h"

bool scan_network(hwNode & n);
#endif
