#ifndef _PCMCIA_H_
#define _PCMCIA_H_

#include "hw.h"

bool scan_pcmcia(hwNode & n);
#endif
