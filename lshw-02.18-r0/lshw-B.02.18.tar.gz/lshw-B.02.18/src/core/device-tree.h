#ifndef _DEVICETREE_H_
#define _DEVICETREE_H_

#include "hw.h"

bool scan_device_tree(hwNode & n);
#endif
