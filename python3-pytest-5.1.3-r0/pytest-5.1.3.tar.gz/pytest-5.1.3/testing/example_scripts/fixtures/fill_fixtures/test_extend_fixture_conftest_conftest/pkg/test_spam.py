def test_spam(spam):
    assert spam == "spamspam"
