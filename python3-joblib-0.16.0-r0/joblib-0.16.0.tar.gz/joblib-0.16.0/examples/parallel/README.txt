.. _parallel_examples:

Parallel examples
-----------------

Examples demoing more advanced parallel patterns.
