.. _contributing:

.. include:: ../.github/CONTRIBUTING.rst

.. include:: ../.github/CODE_OF_CONDUCT.rst
