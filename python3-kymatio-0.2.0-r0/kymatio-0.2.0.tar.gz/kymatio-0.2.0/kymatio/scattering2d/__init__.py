from .frontend.entry import ScatteringEntry2D


__all__ = ['ScatteringEntry2D']
